"""起動: python main.py [--config config.yaml] [--port 8765]"""
import argparse

import uvicorn

from codeagent.config import Config
from codeagent.server.app import create_app


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=None)
    ap.add_argument("--host", default=None)
    ap.add_argument("--port", type=int, default=None)
    args = ap.parse_args()
    cfg = Config.load(args.config)
    host = args.host or cfg.get("server.host", "127.0.0.1")
    port = args.port or int(cfg.get("server.port", 8765))
    print(f"CodeAgent: http://{host}:{port}  model={cfg.get('llm.model')}  workspace={cfg.workspace_root}")
    uvicorn.run(create_app(cfg), host=host, port=port, log_level="warning")


if __name__ == "__main__":
    main()
