"""エージェントループ: ユーザー入力 → LLM → ツール実行 → LLM … を繰り返す。

UI とは emit(event: dict) コールバックと、承認要求用の ask_approval コルーチンで接続する。
"""
from __future__ import annotations

import asyncio
import json
import time
import traceback
from pathlib import Path
from typing import Any, Awaitable, Callable

from . import tools as T
from .config import Config
from .llm import LLMClient
from .prompts import build_system_prompt
from .session import Session, SessionStore

Emit = Callable[[dict], Awaitable[None]]
AskApproval = Callable[[dict], Awaitable[str]]  # 戻り値: "allow" | "allow_always" | "deny"


class Agent:
    def __init__(self, cfg: Config, llm: LLMClient, store: SessionStore):
        self.cfg = cfg
        self.llm = llm
        self.store = store
        self.session_allow: dict[str, set[str]] = {}  # session_id -> 常時許可したツール名
        self._cancel: dict[str, asyncio.Event] = {}
        T.load_builtin()

    def cancel(self, session_id: str):
        ev = self._cancel.get(session_id)
        if ev:
            ev.set()

    # ------------------------------------------------------------------ 権限
    def _decide(self, session: Session, name: str, args: dict) -> str:
        mode = self.cfg.permission(name)
        if mode in ("allow", "deny"):
            return mode
        if name in self.session_allow.get(session.id, set()):
            return "allow"
        if name == "run_command":
            cmd = str(args.get("command", "")).strip()
            for pat in self.cfg.get("permissions.auto_allow_commands", []) or []:
                if cmd.startswith(pat):
                    return "allow"
        return "ask"

    # ------------------------------------------------------------------ 実行
    async def run(self, session: Session, user_text: str, emit: Emit, ask_approval: AskApproval):
        cancel = asyncio.Event()
        self._cancel[session.id] = cancel
        project = Path(session.project_dir)
        ctx = T.ToolContext(self.cfg, project)
        system = build_system_prompt(project, self.cfg.workspace_root)

        session.messages.append({"role": "user", "content": user_text, "ts": time.time()})
        if session.title == "新しいセッション":
            session.title = user_text.strip().splitlines()[0][:40]
        self.store.save(session)

        max_iter = int(self.cfg.get("llm.max_iterations", 40))
        try:
            for _ in range(max_iter):
                if cancel.is_set():
                    await emit({"type": "info", "text": "中断しました"})
                    break
                text_parts: list[str] = []
                tool_calls: list[dict] = []
                try:
                    async for kind, data in self.llm.chat(system, self._history(session), T.schemas()):
                        if cancel.is_set():
                            break
                        if kind == "text":
                            text_parts.append(data)
                            await emit({"type": "text", "delta": data})
                        elif kind == "tool_call":
                            tool_calls.append(data)
                        elif kind == "done":
                            session.usage["prompt_tokens"] += data.get("prompt_tokens", 0)
                            session.usage["completion_tokens"] += data.get("completion_tokens", 0)
                except Exception as e:  # LLM 通信エラー
                    await emit({"type": "error", "text": f"LLM エラー: {e}"})
                    break

                content = "".join(text_parts)
                session.messages.append({"role": "assistant", "content": content, "tool_calls": tool_calls,
                                         "ts": time.time()})
                self.store.save(session)
                if not tool_calls:
                    break

                for tc in tool_calls:
                    if cancel.is_set():
                        break
                    result = await self._exec_tool(session, ctx, tc, emit, ask_approval)
                    session.messages.append({"role": "tool", "tool_call_id": tc["id"], "name": tc["name"],
                                             "content": result, "ts": time.time()})
                    self.store.save(session)
            else:
                await emit({"type": "info", "text": f"ツール呼び出し上限 ({max_iter}) に達したため停止しました"})
        finally:
            self._cancel.pop(session.id, None)
            self.store.save(session)
            await emit({"type": "done", "usage": session.usage})

    async def _exec_tool(self, session: Session, ctx: T.ToolContext, tc: dict, emit: Emit,
                         ask_approval: AskApproval) -> str:
        name, args = tc.get("name"), tc.get("args") or {}
        tool = T.get(name) if name else None
        if not tool:
            msg = f"不明なツール: {name}"
            await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": msg, "error": True})
            return msg
        summary = tool.summarize(args)
        await emit({"type": "tool_call", "id": tc["id"], "name": name, "args": args, "summary": summary})

        decision = self._decide(session, name, args)
        if decision == "ask":
            decision = await ask_approval({"id": tc["id"], "name": name, "args": args, "summary": summary})
            if decision == "allow_always":
                self.session_allow.setdefault(session.id, set()).add(name)
                decision = "allow"
        if decision != "allow":
            msg = "ユーザーがこの操作を拒否しました。別の方法を検討するか、ユーザーに確認してください。"
            await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": msg, "error": True})
            return msg

        t0 = time.time()
        try:
            out = await tool.handler(ctx, args)
            err = False
        except T.ToolError as e:
            out, err = f"エラー: {e}", True
        except Exception as e:
            out, err = f"エラー: {type(e).__name__}: {e}\n{traceback.format_exc()[-1500:]}", True
        await emit({"type": "tool_result", "id": tc["id"], "name": name, "output": out, "error": err,
                    "elapsed": round(time.time() - t0, 2)})
        return out

    # ---------------------------------------------------------------- 履歴
    def _history(self, session: Session) -> list[dict]:
        """LLM に渡す履歴。コンテキスト節約のため古いツール結果は短縮する。"""
        msgs = [{k: v for k, v in m.items() if k != "ts"} for m in session.messages]
        # 直近 6 件以外のツール結果は 1500 文字に切り詰める
        tool_idx = [i for i, m in enumerate(msgs) if m["role"] == "tool"]
        for i in tool_idx[:-6]:
            c = msgs[i]["content"]
            if len(c) > 1500:
                msgs[i]["content"] = c[:1500] + "\n...(省略)"
        return msgs
