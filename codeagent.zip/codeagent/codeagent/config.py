"""設定ファイルの読み込み。"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

DEFAULT_CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.yaml"


def expand(p: str | Path) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(str(p)))).resolve()


class Config:
    def __init__(self, data: dict[str, Any]):
        self.data = data

    @classmethod
    def load(cls, path: str | Path | None = None) -> "Config":
        path = Path(path) if path else DEFAULT_CONFIG_PATH
        with open(path, encoding="utf-8") as f:
            return cls(yaml.safe_load(f) or {})

    def get(self, dotted: str, default: Any = None) -> Any:
        cur: Any = self.data
        for key in dotted.split("."):
            if not isinstance(cur, dict) or key not in cur:
                return default
            cur = cur[key]
        return cur

    # --- よく使う値 ---
    @property
    def workspace_root(self) -> Path:
        return expand(self.get("workspace.root", "~"))

    @property
    def default_project(self) -> Path:
        return expand(self.get("workspace.default_project", self.workspace_root))

    @property
    def sessions_dir(self) -> Path:
        p = expand(self.get("server.sessions_dir", "~/.codeagent/sessions"))
        p.mkdir(parents=True, exist_ok=True)
        return p

    def permission(self, tool_name: str) -> str:
        return str(self.get(f"permissions.{tool_name}", "ask"))
