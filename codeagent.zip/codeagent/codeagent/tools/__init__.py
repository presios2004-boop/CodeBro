"""ツールレジストリ。各ツールは Tool を継承し、register() で登録する。"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Awaitable

from ..config import Config


class ToolError(Exception):
    pass


@dataclass
class ToolContext:
    cfg: Config
    project_dir: Path

    def resolve(self, path: str) -> Path:
        """ワークスペース外へのアクセスを拒否しつつパスを解決する。"""
        p = Path(path).expanduser()
        if not p.is_absolute():
            p = self.project_dir / p
        p = p.resolve()
        root = self.cfg.workspace_root
        if root != p and root not in p.parents:
            raise ToolError(f"ワークスペース外のパスです: {p}（許可: {root} 配下）")
        return p


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict[str, Any]
    handler: Callable[[ToolContext, dict[str, Any]], Awaitable[str]]
    # UI に表示する要約を作る（承認ダイアログ用）
    summarize: Callable[[dict[str, Any]], str] = field(default=lambda a: "")

    def schema(self) -> dict:
        return {"type": "function", "function": {
            "name": self.name, "description": self.description, "parameters": self.parameters}}


_REGISTRY: dict[str, Tool] = {}


def register(tool: Tool) -> Tool:
    _REGISTRY[tool.name] = tool
    return tool


def get(name: str) -> Tool | None:
    return _REGISTRY.get(name)


def all_tools() -> list[Tool]:
    return list(_REGISTRY.values())


def schemas() -> list[dict]:
    return [t.schema() for t in _REGISTRY.values()]


def load_builtin():
    from . import fs, shell, mt5  # noqa: F401  (import で登録される)
