"""ファイル操作ツール: read_file / write_file / edit_file / list_dir / glob / grep"""
from __future__ import annotations

import fnmatch
import re
from pathlib import Path

from . import Tool, ToolContext, ToolError, register

MAX_READ_CHARS = 60_000
IGNORE_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", ".mypy_cache", ".pytest_cache"}


async def read_file(ctx: ToolContext, a: dict) -> str:
    p = ctx.resolve(a["path"])
    if not p.is_file():
        raise ToolError(f"ファイルがありません: {p}")
    text = p.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    start = max(int(a.get("start_line", 1)), 1)
    end = int(a.get("end_line", 0)) or len(lines)
    sel = lines[start - 1:end]
    out = "\n".join(f"{i:5d}| {l}" for i, l in enumerate(sel, start))
    if len(out) > MAX_READ_CHARS:
        out = out[:MAX_READ_CHARS] + f"\n... (省略: 全{len(lines)}行。start_line/end_line で範囲指定してください)"
    return out or "(空ファイル)"


async def write_file(ctx: ToolContext, a: dict) -> str:
    p = ctx.resolve(a["path"])
    p.parent.mkdir(parents=True, exist_ok=True)
    existed = p.exists()
    p.write_text(a["content"], encoding="utf-8")
    return f"{'上書き' if existed else '作成'}: {p} ({len(a['content'])} 文字)"


async def edit_file(ctx: ToolContext, a: dict) -> str:
    p = ctx.resolve(a["path"])
    if not p.is_file():
        raise ToolError(f"ファイルがありません: {p}")
    text = p.read_text(encoding="utf-8")
    old, new = a["old_string"], a["new_string"]
    n = text.count(old)
    if n == 0:
        raise ToolError("old_string がファイル中に見つかりません。read_file で正確な文字列を確認してください")
    if n > 1 and not a.get("replace_all"):
        raise ToolError(f"old_string が {n} 箇所に一致します。周辺行を含めて一意にするか replace_all=true を指定してください")
    text = text.replace(old, new) if a.get("replace_all") else text.replace(old, new, 1)
    p.write_text(text, encoding="utf-8")
    return f"編集完了: {p} ({n} 箇所)"


async def list_dir(ctx: ToolContext, a: dict) -> str:
    p = ctx.resolve(a.get("path", "."))
    if not p.is_dir():
        raise ToolError(f"ディレクトリがありません: {p}")
    rows = []
    for child in sorted(p.iterdir(), key=lambda c: (not c.is_dir(), c.name.lower())):
        if child.name in IGNORE_DIRS:
            continue
        if child.is_dir():
            rows.append(f"{child.name}/")
        else:
            rows.append(f"{child.name}  ({child.stat().st_size} B)")
    return f"{p}\n" + ("\n".join(rows) if rows else "(空)")


def _walk(root: Path):
    for p in root.rglob("*"):
        if any(part in IGNORE_DIRS for part in p.relative_to(root).parts):
            continue
        yield p


async def glob_tool(ctx: ToolContext, a: dict) -> str:
    root = ctx.resolve(a.get("path", "."))
    pat = a["pattern"]
    hits = [str(p.relative_to(root)) for p in _walk(root) if p.is_file() and fnmatch.fnmatch(str(p.relative_to(root)), pat)]
    hits.sort()
    if len(hits) > 500:
        return "\n".join(hits[:500]) + f"\n... (他 {len(hits)-500} 件)"
    return "\n".join(hits) or "(該当なし)"


async def grep(ctx: ToolContext, a: dict) -> str:
    root = ctx.resolve(a.get("path", "."))
    rx = re.compile(a["pattern"], re.I if a.get("ignore_case") else 0)
    include = a.get("include")
    out, count = [], 0
    files = [root] if root.is_file() else [p for p in _walk(root) if p.is_file()]
    for f in files:
        if include and not fnmatch.fnmatch(f.name, include):
            continue
        try:
            for i, line in enumerate(f.read_text(encoding="utf-8", errors="ignore").splitlines(), 1):
                if rx.search(line):
                    out.append(f"{f.relative_to(root) if f != root else f.name}:{i}: {line.strip()[:200]}")
                    count += 1
                    if count >= 300:
                        out.append("... (300件で打ち切り)")
                        return "\n".join(out)
        except OSError:
            continue
    return "\n".join(out) or "(該当なし)"


register(Tool("read_file", "ファイルの内容を行番号付きで読む。大きいファイルは start_line/end_line で範囲指定。",
              {"type": "object", "properties": {
                  "path": {"type": "string", "description": "ファイルパス（プロジェクト相対 or 絶対）"},
                  "start_line": {"type": "integer"}, "end_line": {"type": "integer"}},
               "required": ["path"]}, read_file, lambda a: a.get("path", "")))

register(Tool("write_file", "ファイルを新規作成または全体を上書きする。既存ファイルの部分修正には edit_file を使う。",
              {"type": "object", "properties": {
                  "path": {"type": "string"}, "content": {"type": "string", "description": "ファイル全体の内容"}},
               "required": ["path", "content"]}, write_file,
              lambda a: f"{a.get('path','')} ({len(a.get('content',''))} 文字)"))

register(Tool("edit_file", "ファイル内の old_string を new_string に置換する。old_string はファイル中で一意である必要がある。",
              {"type": "object", "properties": {
                  "path": {"type": "string"}, "old_string": {"type": "string"}, "new_string": {"type": "string"},
                  "replace_all": {"type": "boolean"}},
               "required": ["path", "old_string", "new_string"]}, edit_file, lambda a: a.get("path", "")))

register(Tool("list_dir", "ディレクトリの内容を一覧する。",
              {"type": "object", "properties": {"path": {"type": "string"}}}, list_dir, lambda a: a.get("path", ".")))

register(Tool("glob", "パターンに一致するファイルを再帰的に探す（例: **/*.mq5, src/*.py）。",
              {"type": "object", "properties": {"pattern": {"type": "string"}, "path": {"type": "string"}},
               "required": ["pattern"]}, glob_tool, lambda a: a.get("pattern", "")))

register(Tool("grep", "正規表現でファイル内容を検索する。",
              {"type": "object", "properties": {
                  "pattern": {"type": "string"}, "path": {"type": "string"},
                  "include": {"type": "string", "description": "ファイル名パターン 例: *.mq5"},
                  "ignore_case": {"type": "boolean"}},
               "required": ["pattern"]}, grep, lambda a: a.get("pattern", "")))
