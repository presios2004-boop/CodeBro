"""MT5 (wine) 向けツール: mt5_compile / mt5_backtest

前提: WINEPREFIX 配下に MetaTrader 5 がインストールされ、MetaEditor64.exe / terminal64.exe が存在すること。
"""
from __future__ import annotations

import re
import shutil
import time
from pathlib import Path

from ..config import expand
from . import Tool, ToolContext, ToolError, register
from .shell import run_shell


def _mt5_paths(ctx: ToolContext) -> dict[str, Path]:
    cfg = ctx.cfg
    prefix = expand(cfg.get("mt5.wine_prefix", "~/.wine_oanda_mt5"))
    terminal_dir = prefix / cfg.get("mt5.terminal_dir")
    mql5_dir = prefix / cfg.get("mt5.mql5_dir")
    return {"prefix": prefix, "terminal_dir": terminal_dir, "mql5_dir": mql5_dir,
            "metaeditor": terminal_dir / "MetaEditor64.exe", "terminal": terminal_dir / "terminal64.exe"}


def _to_win(prefix: Path, p: Path) -> str:
    """WINEPREFIX/drive_c/... を C:\\... に変換する。"""
    rel = p.resolve().relative_to((prefix / "drive_c").resolve())
    return "C:\\" + str(rel).replace("/", "\\")


def _read_win_text(p: Path) -> str:
    raw = p.read_bytes()
    for enc in ("utf-16", "utf-8", "cp932"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1")


def _place_source(ctx: ToolContext, src: Path, mql5_dir: Path) -> Path:
    """ソースが MQL5 フォルダ外なら MQL5/Experts/CodeAgent/ にコピーして、その先のパスを返す。"""
    if mql5_dir.resolve() in src.resolve().parents:
        return src
    dest_dir = mql5_dir / "Experts" / "CodeAgent"
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / src.name
    shutil.copy2(src, dest)
    # 同階層の .mqh も一緒にコピー（インクルード用）
    for inc in src.parent.glob("*.mqh"):
        shutil.copy2(inc, dest_dir / inc.name)
    return dest


async def mt5_compile(ctx: ToolContext, a: dict) -> str:
    paths = _mt5_paths(ctx)
    if not paths["metaeditor"].exists():
        raise ToolError(f"MetaEditor64.exe が見つかりません: {paths['metaeditor']}（config.yaml の mt5 設定を確認）")
    src = ctx.resolve(a["path"])
    if src.suffix.lower() not in (".mq5", ".mq4"):
        raise ToolError("拡張子は .mq5 である必要があります")
    if not src.exists():
        raise ToolError(f"ファイルがありません: {src}")
    placed = _place_source(ctx, src, paths["mql5_dir"])
    log = placed.with_suffix(".log")
    if log.exists():
        log.unlink()
    win_src = _to_win(paths["prefix"], placed)
    win_log = _to_win(paths["prefix"], log)
    cmd = f'wine "{paths["metaeditor"]}" /compile:"{win_src}" /log:"{win_log}"'
    env = {"WINEPREFIX": str(paths["prefix"]), "WINEDEBUG": "-all"}
    code, out = await run_shell(cmd, str(paths["terminal_dir"]), timeout=int(a.get("timeout", 180)), env=env)
    result = []
    if log.exists():
        text = _read_win_text(log)
        result.append(text.strip())
        errs = re.findall(r"(\d+)\s+error", text)
        warns = re.findall(r"(\d+)\s+warning", text)
        ok = "Result: 0 errors" in text or (errs and errs[-1] == "0")
        result.insert(0, f"[{'成功' if ok else '失敗'}] errors={errs[-1] if errs else '?'} warnings={warns[-1] if warns else '?'}")
    else:
        result.append(f"ログが生成されませんでした (exit {code})\n{out[-2000:]}")
    ex5 = placed.with_suffix(".ex5")
    if ex5.exists():
        result.append(f"出力: {ex5}")
        if placed != src:
            shutil.copy2(ex5, src.with_suffix(".ex5"))
            result.append(f"コピー: {src.with_suffix('.ex5')}")
    return "\n".join(result)


def _parse_report(html: str) -> str:
    """ストラテジーテスターの HTML レポートから主要指標を抜き出す。"""
    text = re.sub(r"<[^>]+>", "\t", html)
    text = re.sub(r"[\t ]+", " ", text)
    keys = ["Total Net Profit", "Profit Factor", "Expected Payoff", "Sharpe Ratio", "Recovery Factor",
            "Balance Drawdown Maximal", "Equity Drawdown Maximal", "Total Trades", "Profit Trades",
            "純利益", "プロフィットファクタ", "期待利得", "シャープレシオ", "最大ドローダウン", "総取引数"]
    found = []
    for k in keys:
        m = re.search(re.escape(k) + r":?\s*([-\d.,%()\s]+)", text)
        if m:
            found.append(f"{k}: {m.group(1).strip()[:40]}")
    return "\n".join(found) if found else "(指標を抽出できませんでした。レポートを直接確認してください)"


async def mt5_backtest(ctx: ToolContext, a: dict) -> str:
    paths = _mt5_paths(ctx)
    if not paths["terminal"].exists():
        raise ToolError(f"terminal64.exe が見つかりません: {paths['terminal']}")
    t = ctx.cfg.get("mt5.tester", {})
    src = ctx.resolve(a["path"])
    ex5 = src if src.suffix == ".ex5" else src.with_suffix(".ex5")
    placed = _place_source(ctx, src if src.suffix == ".mq5" else src.with_suffix(".mq5"), paths["mql5_dir"]) \
        if src.with_suffix(".mq5").exists() else None
    placed_ex5 = (placed.with_suffix(".ex5") if placed else ex5)
    if ex5.exists() and placed and not placed_ex5.exists():
        shutil.copy2(ex5, placed_ex5)
    if not placed_ex5.exists():
        raise ToolError(f"コンパイル済み .ex5 がありません: {placed_ex5}。先に mt5_compile を実行してください")
    experts_dir = paths["mql5_dir"] / "Experts"
    expert_rel = str(placed_ex5.relative_to(experts_dir)).replace("/", "\\")
    report_name = f"CodeAgent_{placed_ex5.stem}_{int(time.time())}"
    ini = paths["terminal_dir"] / "codeagent_tester.ini"
    ini_text = "\n".join([
        "[Tester]",
        f"Expert={expert_rel}",
        f"Symbol={a.get('symbol', t.get('symbol', 'USDJPY'))}",
        f"Period={a.get('period', t.get('period', 'H1'))}",
        f"Model={a.get('model', t.get('model', 1))}",
        f"FromDate={a.get('from_date', t.get('from', '2024.01.01'))}",
        f"ToDate={a.get('to_date', t.get('to', '2024.12.31'))}",
        f"Deposit={t.get('deposit', 1000000)}",
        f"Leverage={t.get('leverage', 25)}",
        "Optimization=0",
        "Visual=0",
        f"Report={report_name}",
        "ReplaceReport=1",
        "ShutdownTerminal=1",
        "",
    ])
    if a.get("set_file"):
        ini_text += f"ExpertParameters={a['set_file']}\n"
    ini.write_text(ini_text, encoding="utf-8")
    cmd = f'wine "{paths["terminal"]}" /config:"{_to_win(paths["prefix"], ini)}"'
    env = {"WINEPREFIX": str(paths["prefix"]), "WINEDEBUG": "-all"}
    code, out = await run_shell(cmd, str(paths["terminal_dir"]), timeout=int(a.get("timeout", 1800)), env=env)
    report = paths["terminal_dir"] / f"{report_name}.htm"
    if not report.exists():
        return (f"バックテストのレポートが見つかりません (exit {code})。\n"
                f"ini: {ini}\nログ: {paths['terminal_dir']}/logs/ および tester/logs/ を確認してください\n{out[-1500:]}")
    return f"レポート: {report}\n" + _parse_report(_read_win_text(report))


register(Tool("mt5_compile",
              "MQL5 ソース (.mq5) を MetaEditor (wine) でコンパイルし、エラー/警告を返す。EA を書いたら必ず実行して確認する。",
              {"type": "object", "properties": {
                  "path": {"type": "string", "description": ".mq5 ファイルのパス"},
                  "timeout": {"type": "integer"}},
               "required": ["path"]}, mt5_compile, lambda a: a.get("path", "")))

register(Tool("mt5_backtest",
              "コンパイル済み EA をストラテジーテスターでバックテストし、主要指標（純利益・PF・DD 等）を返す。時間がかかる。",
              {"type": "object", "properties": {
                  "path": {"type": "string", "description": ".mq5 または .ex5 のパス"},
                  "symbol": {"type": "string"}, "period": {"type": "string", "description": "M1/M5/M15/H1/H4/D1"},
                  "from_date": {"type": "string", "description": "YYYY.MM.DD"},
                  "to_date": {"type": "string", "description": "YYYY.MM.DD"},
                  "model": {"type": "integer", "description": "0=every tick,1=1min OHLC,2=open only,4=real ticks"},
                  "set_file": {"type": "string", "description": "パラメータ .set ファイル名（任意）"},
                  "timeout": {"type": "integer"}},
               "required": ["path"]}, mt5_backtest, lambda a: a.get("path", "")))
