"""FastAPI サーバー: REST（セッション管理）+ WebSocket（チャット）"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from pydantic import BaseModel

from ..agent import Agent
from ..config import Config, expand
from ..llm import LLMClient
from ..session import Session, SessionStore

STATIC = Path(__file__).parent / "static"


class NewSession(BaseModel):
    project_dir: str | None = None


class SetModel(BaseModel):
    model: str


def create_app(cfg: Config) -> FastAPI:
    app = FastAPI(title="CodeAgent")
    llm = LLMClient(cfg)
    store = SessionStore(cfg.sessions_dir)
    agent = Agent(cfg, llm, store)
    running: dict[str, asyncio.Task] = {}

    @app.get("/")
    async def index():
        return FileResponse(STATIC / "index.html")

    @app.get("/api/config")
    async def get_config():
        return {"model": llm.model, "provider": llm.provider, "tool_mode": llm.tool_mode,
                "workspace": str(cfg.workspace_root), "default_project": str(cfg.default_project),
                "permissions": cfg.get("permissions", {})}

    @app.get("/api/models")
    async def models():
        try:
            async with httpx.AsyncClient(timeout=5) as c:
                r = await c.get(f"{llm.base_url}/api/tags")
                return {"models": [m["name"] for m in r.json().get("models", [])]}
        except Exception as e:
            return {"models": [], "error": str(e)}

    @app.post("/api/model")
    async def set_model(body: SetModel):
        llm.model = body.model
        return {"model": llm.model}

    @app.get("/api/sessions")
    async def list_sessions():
        return store.list()

    @app.post("/api/sessions")
    async def new_session(body: NewSession):
        pdir = expand(body.project_dir) if body.project_dir else cfg.default_project
        if not pdir.is_dir():
            raise HTTPException(400, f"ディレクトリがありません: {pdir}")
        root = cfg.workspace_root
        if pdir != root and root not in pdir.parents:
            raise HTTPException(400, f"ワークスペース外です: {pdir}")
        s = Session.new(str(pdir))
        store.save(s)
        return s.summary()

    @app.get("/api/sessions/{sid}")
    async def get_session(sid: str):
        s = store.load(sid)
        if not s:
            raise HTTPException(404)
        return {"summary": s.summary(), "messages": s.messages, "usage": s.usage}

    @app.delete("/api/sessions/{sid}")
    async def delete_session(sid: str):
        store.delete(sid)
        return {"ok": True}

    @app.websocket("/ws/{sid}")
    async def ws(websocket: WebSocket, sid: str):
        await websocket.accept()
        session = store.load(sid)
        if not session:
            await websocket.send_json({"type": "error", "text": "セッションがありません"})
            await websocket.close()
            return
        pending: dict[str, asyncio.Future] = {}
        send_lock = asyncio.Lock()

        async def emit(ev: dict):
            async with send_lock:
                await websocket.send_json(ev)

        async def ask_approval(req: dict) -> str:
            fut: asyncio.Future = asyncio.get_event_loop().create_future()
            pending[req["id"]] = fut
            await emit({"type": "approval_request", **req})
            try:
                return await fut
            finally:
                pending.pop(req["id"], None)

        try:
            while True:
                raw = await websocket.receive_text()
                msg = json.loads(raw)
                t = msg.get("type")
                if t == "user":
                    if sid in running and not running[sid].done():
                        await emit({"type": "error", "text": "前の処理が実行中です"})
                        continue
                    session = store.load(sid) or session
                    running[sid] = asyncio.create_task(agent.run(session, msg["text"], emit, ask_approval))
                elif t == "approval":
                    fut = pending.get(msg["id"])
                    if fut and not fut.done():
                        fut.set_result(msg.get("decision", "deny"))
                elif t == "cancel":
                    agent.cancel(sid)
                    for fut in pending.values():
                        if not fut.done():
                            fut.set_result("deny")
        except WebSocketDisconnect:
            for fut in pending.values():
                if not fut.done():
                    fut.set_result("deny")

    @app.on_event("shutdown")
    async def shutdown():
        await llm.close()

    return app
