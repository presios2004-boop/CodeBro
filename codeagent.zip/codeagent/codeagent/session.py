"""セッション（会話履歴）の永続化。1セッション = 1 JSON ファイル。"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path


@dataclass
class Session:
    id: str
    project_dir: str
    title: str = "新しいセッション"
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    messages: list[dict] = field(default_factory=list)
    usage: dict = field(default_factory=lambda: {"prompt_tokens": 0, "completion_tokens": 0})

    @classmethod
    def new(cls, project_dir: str) -> "Session":
        return cls(id=time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:6], project_dir=project_dir)

    def summary(self) -> dict:
        return {"id": self.id, "title": self.title, "project_dir": self.project_dir,
                "updated_at": self.updated_at, "n": len(self.messages)}


class SessionStore:
    def __init__(self, root: Path):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)

    def path(self, sid: str) -> Path:
        return self.root / f"{sid}.json"

    def save(self, s: Session):
        s.updated_at = time.time()
        self.path(s.id).write_text(json.dumps(asdict(s), ensure_ascii=False, indent=1), encoding="utf-8")

    def load(self, sid: str) -> Session | None:
        p = self.path(sid)
        if not p.exists():
            return None
        return Session(**json.loads(p.read_text(encoding="utf-8")))

    def list(self) -> list[dict]:
        out = []
        for p in self.root.glob("*.json"):
            try:
                s = self.load(p.stem)
                if s:
                    out.append(s.summary())
            except Exception:
                continue
        return sorted(out, key=lambda x: x["updated_at"], reverse=True)

    def delete(self, sid: str):
        p = self.path(sid)
        if p.exists():
            p.unlink()
